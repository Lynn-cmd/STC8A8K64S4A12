
#ifndef DEF_H
#define DEF_H

sbit  led_d3=P6^4;			 //����P6.4�� LEDָʾ��
sbit  led_d2=P5^5;			 //����P5.5�� LEDָʾ��

//#define uchar unsigned char  
//#define uint  unsigned int 
#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long
//u8 asc1[10]={48,49,50,51,52,53,54,55,56,57};

#endif

